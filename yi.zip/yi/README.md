This is simulation that is based on I Ching.
Give Birth To AI, with ATOMIC INT.

Also, this is some kind of simulated quantum computer. Although this is just an emulation, this still works!
# I-Ching
