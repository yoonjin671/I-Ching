while true||false&do ./pat|./pattern|./pat&done

